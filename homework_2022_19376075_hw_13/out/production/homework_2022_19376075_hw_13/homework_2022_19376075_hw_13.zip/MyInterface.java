import java.util.ArrayList;
import java.util.HashMap;

public class MyInterface {
    private final String id;
    private final String name;
    private final HashMap<String, MyInterface> fathers;

    public MyInterface(String id, String name) {
        this.id = id;
        this.name = name;
        fathers = new HashMap<>();
    }

    public void addFather(MyInterface myInterface) {
        fathers.put(myInterface.id, myInterface);
    }

    public void addFamily(MyInterface myInterface, String relationship) {
        switch (relationship) {
            case "father":
                fathers.put(myInterface.id, myInterface);
                return;
            default:
        }
    }

    public ArrayList<String> getClassImplementInterfaceListFather() {
        ArrayList<String> ans = new ArrayList<>();
        ans.add(name);

        for (MyInterface myInterface : fathers.values()) {
            ans.addAll(myInterface.getClassImplementInterfaceListFather());
        }

        return ans;
    }
}
