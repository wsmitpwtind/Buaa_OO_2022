import com.oocourse.uml1.models.common.NameableType;

public class MyAttribute {
    private final NameableType type;

    public MyAttribute(NameableType nameableType) {
        type = nameableType;
    }

    public NameableType getType() {
        return type;
    }
}
