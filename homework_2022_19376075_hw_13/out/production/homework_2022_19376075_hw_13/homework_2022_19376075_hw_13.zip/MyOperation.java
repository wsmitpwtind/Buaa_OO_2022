import com.oocourse.uml1.models.common.Direction;
import com.oocourse.uml1.models.common.NameableType;
import com.oocourse.uml1.models.common.ReferenceType;
import com.oocourse.uml1.models.common.Visibility;
import com.oocourse.uml1.models.common.NamedType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MyOperation {
    private final String name;
    private final Visibility visibility;
    private NameableType outNameableType;
    private final ArrayList<NameableType> inNameableType;
    private final List<String> outType;
    private final List<String> inType;

    public MyOperation(String name, Visibility visibility) {
        this.name = name;
        this.visibility = visibility;
        this.outNameableType = null;
        this.inNameableType = new ArrayList<>();
        this.outType = new ArrayList<>();
        this.inType = new ArrayList<>();
        initialType();
    }

    public void initialType() {
        add(outType);
        outType.add("void");
        add(inType);
    }

    private void add(List<String> type) {
        type.add("byte");
        type.add("short");
        type.add("int");
        type.add("long");
        type.add("float");
        type.add("double");
        type.add("char");
        type.add("boolean");
        type.add("String");
    }

    public String getName() {
        return name;
    }

    public Visibility getVisibility() {
        return visibility;
    }

    public void addParameter(Direction direction, NameableType nameableType) {
        if (direction == Direction.IN) {
            this.inNameableType.add(nameableType);
        }
        if (direction == Direction.RETURN) {
            this.outNameableType = nameableType;
        }
    }

    public boolean checkDuplicatedMethod(MyOperation operation) {
        if (inNameableType.size() == operation.inNameableType.size()) {
            for (NameableType type2 : inNameableType) {
                if (!operation.inNameableType.contains(type2)) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    public int getClassOperationCouplingDegree(String inputId) {
        int ans = 0;
        HashMap<String, Boolean> answer = new HashMap<>();
        answer.put(inputId, true);
        for (NameableType type : inNameableType) {
            if (type instanceof ReferenceType) {
                if (!answer.containsKey(((ReferenceType) type).getReferenceId())) {
                    answer.put(((ReferenceType) type).getReferenceId(), true);
                    ans++;
                }
            }
        }
        if (outNameableType != null) {
            if (outNameableType instanceof ReferenceType) {
                if (!answer.containsKey(((ReferenceType) outNameableType).getReferenceId())) {
                    answer.put(((ReferenceType) outNameableType).getReferenceId(), true);
                    ans++;
                }
            }
        }
        return ans;
    }

    public boolean checkWrongType() {
        if (outNameableType != null) {
            if (outNameableType instanceof NamedType) {
                if (!outType.contains(((NamedType) outNameableType).getName())) {
                    return true;
                }
            }
        }
        for (NameableType nameableType : inNameableType) {
            if (nameableType instanceof NamedType) {
                if (!inType.contains(((NamedType) nameableType).getName())) {
                    return true;
                }
            }
        }
        return false;
    }
}
