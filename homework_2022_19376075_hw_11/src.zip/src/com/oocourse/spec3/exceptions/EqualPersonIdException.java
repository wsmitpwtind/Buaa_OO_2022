package com.oocourse.spec3.exceptions;

public abstract class EqualPersonIdException extends Exception {

    public abstract void print();
}
