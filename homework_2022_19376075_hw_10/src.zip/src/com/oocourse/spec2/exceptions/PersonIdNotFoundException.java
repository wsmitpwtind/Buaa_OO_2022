package com.oocourse.spec2.exceptions;

public abstract class PersonIdNotFoundException extends Exception {

    public abstract void print();
}
