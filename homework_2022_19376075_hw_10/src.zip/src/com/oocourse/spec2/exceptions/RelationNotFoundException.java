package com.oocourse.spec2.exceptions;

public abstract class RelationNotFoundException extends Exception {

    public abstract void print();
}
