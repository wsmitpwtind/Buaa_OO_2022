package com.oocourse.spec2.exceptions;

public abstract class GroupIdNotFoundException extends Exception {

    public abstract void print();
}
